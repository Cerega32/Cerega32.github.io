'use strict';
var use = "dsds";
alert("use");